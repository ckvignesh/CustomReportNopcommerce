﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.RefundReport.Models
{
    public record TransactionListModel : BasePagedListModel<RRTransactionModel>
    {

    }
}