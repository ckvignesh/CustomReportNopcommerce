﻿using FluentMigrator;
using Nop.Data.Extensions;
using Nop.Data.Migrations;
using Nop.Plugin.FinanceReport.Domain;

//namespace Nop.Plugin.FinanceReport.Data
//{
//    [NopMigration("2022/11/08 09:30:17:6455422", "FinanceReport base schema", MigrationProcessType.Installation)]
//    public class SchemaMigration : AutoReversingMigration
//    {
//        public override void Up()
//        {
//            Create.TableFor<FinanceReportransactionLog>();
//        }
//    }
//}