﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.FinanceReport.Models
{
    public record TransactionListModel : BasePagedListModel<FRTransactionModel>
    {

    }
}