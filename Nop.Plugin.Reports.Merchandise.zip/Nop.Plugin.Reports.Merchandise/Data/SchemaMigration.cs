﻿using FluentMigrator;
using Nop.Data.Extensions;
using Nop.Data.Migrations;
using Nop.Plugin.Reports.Merchandise.Domain;

//namespace Nop.Plugin.Reports.Merchandise.Data
//{
//    [NopMigration("2022/11/08 09:30:17:6455422", "Payments.ENETS base schema", MigrationProcessType.Installation)]
//    public class SchemaMigration : AutoReversingMigration
//    {
//        public override void Up()
//        {
//            Create.TableFor<MerchandiseTransactionLog>();
//        }
//    }
//}